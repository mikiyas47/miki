package com.example.simpleexm;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddQuestionsActivity extends AppCompatActivity {

    private EditText questionInput;
    private EditText optionAInput;
    private EditText optionBInput;
    private EditText optionCInput;
    private EditText optionDInput;
    private EditText correctAnswerInput;  // Added for correct answer
    private Button submitButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_questions);

        // Initialize views
        questionInput = findViewById(R.id.questionInput);
        optionAInput = findViewById(R.id.optionAInput);
        optionBInput = findViewById(R.id.optionBInput);
        optionCInput = findViewById(R.id.optionCInput);
        optionDInput = findViewById(R.id.optionDInput);
        correctAnswerInput = findViewById(R.id.correctAnswerInput);  // Initialize correct answer input
        submitButton = findViewById(R.id.submitButton);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Set OnClickListener for the submit button
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String question = questionInput.getText().toString().trim();
                String optionA = optionAInput.getText().toString().trim();
                String optionB = optionBInput.getText().toString().trim();
                String optionC = optionCInput.getText().toString().trim();
                String optionD = optionDInput.getText().toString().trim();
                String correctAnswer = correctAnswerInput.getText().toString().trim();  // Get correct answer

                // Validate that all fields are filled in
                if (!question.isEmpty() && !optionA.isEmpty() && !optionB.isEmpty() &&
                        !optionC.isEmpty() && !optionD.isEmpty() && !correctAnswer.isEmpty()) {
                    // Save the question to the database
                    saveQuestionToDatabase(question, optionA, optionB, optionC, optionD, correctAnswer);
                    Toast.makeText(AddQuestionsActivity.this, "Question Added Successfully!", Toast.LENGTH_SHORT).show();
                    clearFields();  // Clear input fields
                } else {
                    Toast.makeText(AddQuestionsActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Save question and its options to the database
    private void saveQuestionToDatabase(String question, String optionA, String optionB, String optionC, String optionD, String correctAnswer) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(DatabaseHelper.COLUMN_QUESTION, question);
        values.put(DatabaseHelper.COLUMN_OPTION_A, optionA);
        values.put(DatabaseHelper.COLUMN_OPTION_B, optionB);
        values.put(DatabaseHelper.COLUMN_OPTION_C, optionC);
        values.put(DatabaseHelper.COLUMN_OPTION_D, optionD);
        values.put("correct_answer", correctAnswer);  // Save the correct answer

        // Insert the question into the database
        long newRowId = db.insert(DatabaseHelper.TABLE_QUESTIONS, null, values);

        // Close the database
        db.close();

        // Check if the insertion was successful
        if (newRowId == -1) {
            Toast.makeText(this, "Error occurred while adding question", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Question added with ID: " + newRowId, Toast.LENGTH_SHORT).show();
        }
    }

    // Clear input fields after adding a question
    private void clearFields() {
        questionInput.setText("");
        optionAInput.setText("");
        optionBInput.setText("");
        optionCInput.setText("");
        optionDInput.setText("");
        correctAnswerInput.setText("");  // Clear the correct answer input field
    }
}
