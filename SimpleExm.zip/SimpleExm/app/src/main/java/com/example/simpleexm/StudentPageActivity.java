package com.example.simpleexm;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class StudentPageActivity extends AppCompatActivity {

    private TextView welcomeText;
    private Button takeExamButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_page);

        welcomeText = findViewById(R.id.studentNameText);
        takeExamButton = findViewById(R.id.takeExamButton);

        String username = getIntent().getStringExtra("USERNAME");
        if (username != null) {
            welcomeText.setText("Welcome, " + username);
        } else {
            welcomeText.setText("Welcome, Student");
        }

        takeExamButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StudentPageActivity.this, ExamActivity.class); // Assuming you have an ExamActivity
                startActivity(intent);
            }
        });
    }
}
