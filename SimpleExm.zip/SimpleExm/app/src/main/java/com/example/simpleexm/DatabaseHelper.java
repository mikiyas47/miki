package com.example.simpleexm;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "questions.db";
    private static final int DATABASE_VERSION = 6; // Incremented for new features

    // Table for Questions
    public static final String TABLE_QUESTIONS = "questions";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_QUESTION = "question";
    public static final String COLUMN_OPTION_A = "optionA";
    public static final String COLUMN_OPTION_B = "optionB";
    public static final String COLUMN_OPTION_C = "optionC";
    public static final String COLUMN_OPTION_D = "optionD";
    public static final String COLUMN_CORRECT_ANSWER = "correct_answer";

    // Table for Students
    public static final String TABLE_STUDENTS = "students";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "NAME";
    public static final String COL_3 = "PASSWORD";

    // Table for storing student scores
    public static final String TABLE_SCORES = "scores";
    public static final String SCORE_ID = "score_id";
    public static final String STUDENT_NAME = "student_name";
    public static final String SCORE = "score";

    // SQL command to create the `questions` table
    private static final String CREATE_TABLE_QUESTIONS =
            "CREATE TABLE " + TABLE_QUESTIONS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_QUESTION + " TEXT NOT NULL, " +
                    COLUMN_OPTION_A + " TEXT NOT NULL, " +
                    COLUMN_OPTION_B + " TEXT NOT NULL, " +
                    COLUMN_OPTION_C + " TEXT NOT NULL, " +
                    COLUMN_OPTION_D + " TEXT NOT NULL, " +
                    COLUMN_CORRECT_ANSWER + " TEXT NOT NULL);";

    // SQL command to create the `students` table
    private static final String CREATE_TABLE_STUDENTS =
            "CREATE TABLE " + TABLE_STUDENTS + " (" +
                    COL_1 + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_2 + " TEXT UNIQUE NOT NULL, " +
                    COL_3 + " TEXT NOT NULL);";

    // SQL command to create the `scores` table
    private static final String CREATE_TABLE_SCORES =
            "CREATE TABLE " + TABLE_SCORES + " (" +
                    SCORE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    STUDENT_NAME + " TEXT NOT NULL, " +
                    SCORE + " INTEGER NOT NULL);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_TABLE_STUDENTS);
            db.execSQL(CREATE_TABLE_QUESTIONS);
            db.execSQL(CREATE_TABLE_SCORES);
            Log.d("DatabaseHelper", "Tables created successfully.");
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error creating tables: " + e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d("DatabaseHelper", "Upgrading database from version " + oldVersion + " to " + newVersion);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUESTIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SCORES);
        onCreate(db);
    }

    // Insert student method with password encryption
    public boolean insertStudent(String name, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        String encryptedPassword = EncryptionUtil.encrypt(password); // Encrypt the password

        contentValues.put(COL_2, name);
        contentValues.put(COL_3, encryptedPassword);

        long result = db.insert(TABLE_STUDENTS, null, contentValues);
        return result != -1;
    }

    // Verify student login with decrypted password
    public boolean verifyStudent(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_STUDENTS + " WHERE NAME=?", new String[]{username});

        boolean isVerified = false;

        if (cursor.moveToFirst()) {
            // Get the encrypted password from the database
            @SuppressLint("Range") String encryptedPassword = cursor.getString(cursor.getColumnIndex(COL_3));
            // Decrypt the stored password
            String decryptedPassword = EncryptionUtil.decrypt(encryptedPassword);

            // Compare decrypted password with the entered password
            if (decryptedPassword != null && decryptedPassword.equals(password)) {
                isVerified = true;
            }
        }

        cursor.close();  // Close the cursor to prevent memory leaks
        return isVerified;
    }

    // Retrieve all questions for students
    public Cursor getAllQuestions() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_QUESTIONS, null);
    }

    // Store student's exam score
    public boolean insertScore(String studentName, int score) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(STUDENT_NAME, studentName);
        values.put(SCORE, score);

        long result = db.insert(TABLE_SCORES, null, values);
        return result != -1;
    }

    // Get a student's latest score
    public int getStudentScore(String studentName) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SCORE FROM " + TABLE_SCORES + " WHERE STUDENT_NAME=? ORDER BY SCORE_ID DESC LIMIT 1", new String[]{studentName});

        int score = -1;
        if (cursor.moveToFirst()) {
            score = cursor.getInt(0);
        }
        cursor.close();  // Close the cursor to prevent memory leaks
        return score;
    }
}
