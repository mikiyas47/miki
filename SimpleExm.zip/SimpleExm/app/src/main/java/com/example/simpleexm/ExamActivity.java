package com.example.simpleexm;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ExamActivity extends AppCompatActivity {

    private TextView examWelcomeText, questionText, resultText;
    private RadioGroup optionsGroup;
    private RadioButton optionA, optionB, optionC, optionD;
    private Button submitButton;
    private DatabaseHelper dbHelper;

    private String studentName;
    private int score = 0;
    private int questionIndex = 0;
    private Cursor questionsCursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exam);

        // Initialize views
        examWelcomeText = findViewById(R.id.examWelcomeText);
        questionText = findViewById(R.id.questionText);
        optionsGroup = findViewById(R.id.optionsGroup); // Reference to RadioGroup
        optionA = findViewById(R.id.optionA);
        optionB = findViewById(R.id.optionB);
        optionC = findViewById(R.id.optionC);
        optionD = findViewById(R.id.optionD);
        submitButton = findViewById(R.id.submitButton);
        resultText = findViewById(R.id.resultText);

        dbHelper = new DatabaseHelper(this);

        // Get student name from the intent
        studentName = getIntent().getStringExtra("USERNAME");
        examWelcomeText.setText("Welcome, " + studentName + "!\nPlease take the exam.");

        // Fetch questions from the database
        questionsCursor = dbHelper.getAllQuestions();

        if (questionsCursor.moveToFirst()) {
            displayNextQuestion();
        } else {
            Toast.makeText(this, "No questions available.", Toast.LENGTH_SHORT).show();
        }

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check the answer
                @SuppressLint("Range")
                String correctAnswer = questionsCursor.getString(questionsCursor.getColumnIndex(DatabaseHelper.COLUMN_CORRECT_ANSWER));
                RadioButton selectedOption = findViewById(optionsGroup.getCheckedRadioButtonId());

                // Check if a valid option is selected and whether it matches the correct answer
                if (selectedOption != null && selectedOption.getText().toString().equals(correctAnswer)) {
                    score++;
                }

                // Move to next question
                questionIndex++;
                if (questionsCursor.moveToNext()) {
                    displayNextQuestion();
                } else {
                    // End of the exam, save score
                    dbHelper.insertScore(studentName, score);
                    resultText.setText("Your Score: " + score + "/" + questionIndex);
                    submitButton.setEnabled(false); // Disable submit after exam completion
                }
            }
        });
    }

    @SuppressLint("Range")
    private void displayNextQuestion() {
        // Display the current question and options
        questionText.setText(questionsCursor.getString(questionsCursor.getColumnIndex(DatabaseHelper.COLUMN_QUESTION)));
        optionA.setText(questionsCursor.getString(questionsCursor.getColumnIndex(DatabaseHelper.COLUMN_OPTION_A)));
        optionB.setText(questionsCursor.getString(questionsCursor.getColumnIndex(DatabaseHelper.COLUMN_OPTION_B)));
        optionC.setText(questionsCursor.getString(questionsCursor.getColumnIndex(DatabaseHelper.COLUMN_OPTION_C)));
        optionD.setText(questionsCursor.getString(questionsCursor.getColumnIndex(DatabaseHelper.COLUMN_OPTION_D)));

        // Clear any previously selected option
        optionsGroup.clearCheck();
    }
}
