package com.example.simpleexm;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import android.util.Base64;

public class EncryptionUtil {

    // Secret key for AES encryption/decryption (128 bits)
    private static final String SECRET_KEY = "MySuperSecretKey"; // Change this to your own key for better security

    // Encrypt the data
    public static String encrypt(String data) {
        try {
            // Initialize AES key with the provided SECRET_KEY
            SecretKeySpec secretKey = new SecretKeySpec(SECRET_KEY.getBytes(), "AES");

            // Initialize Cipher for encryption
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);

            // Perform encryption
            byte[] encryptedData = cipher.doFinal(data.getBytes("UTF-8"));  // Ensure UTF-8 encoding
            return Base64.encodeToString(encryptedData, Base64.DEFAULT);  // Return as Base64 string
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Decrypt the data
    public static String decrypt(String encryptedData) {
        try {
            // Initialize AES key with the provided SECRET_KEY
            SecretKeySpec secretKey = new SecretKeySpec(SECRET_KEY.getBytes(), "AES");

            // Initialize Cipher for decryption
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);

            // Decode the encrypted data from Base64
            byte[] decodedData = Base64.decode(encryptedData, Base64.DEFAULT);

            // Perform decryption
            byte[] decryptedData = cipher.doFinal(decodedData);
            return new String(decryptedData, "UTF-8");  // Convert to string using UTF-8 encoding
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
