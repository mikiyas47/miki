package com.example.simpleexm;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class AdminActivity extends AppCompatActivity {

    private Button addQuestionsButton;
    private Button registerButton;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);  // Ensure this matches your layout file name

        addQuestionsButton = findViewById(R.id.addQuestionsButton);
        registerButton = findViewById(R.id.registerButton);


        // Set an OnClickListener for the Add Questions button
        addQuestionsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminActivity.this, AddQuestionsActivity.class);
                startActivity(intent);
            }
        });

        // Set an OnClickListener for the Register Students button
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminActivity.this, RegisterStudentsActivity.class);
                startActivity(intent);
            }
        });


    }
}