package com.example.simpleexm;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginButton;
    private DatabaseHelper dbHelper;

    private static final String ADMIN_USERNAME = "Mikiyas";
    private static final String ADMIN_PASSWORD = "Shalom";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);
        dbHelper = new DatabaseHelper(this);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameInput.getText().toString().trim();
                String password = passwordInput.getText().toString().trim();

                if (username.equals(ADMIN_USERNAME) && password.equals(ADMIN_PASSWORD)) {
                    Intent intent = new Intent(MainActivity.this, AdminActivity.class);
                    startActivity(intent);
                    finish();
                } else if (isStudentValid(username, password)) {
                    Intent intent = new Intent(MainActivity.this, StudentPageActivity.class);
                    intent.putExtra("USERNAME", username);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isStudentValid(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + DatabaseHelper.COL_3 + " FROM " + DatabaseHelper.TABLE_STUDENTS + " WHERE " + DatabaseHelper.COL_2 + " =?", new String[]{username});
        boolean isValid = false;

        if (cursor.moveToFirst()) {
            // Decrypt the password and validate
            @SuppressLint("Range") String encryptedPassword = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_3));
            String decryptedPassword = EncryptionUtil.decrypt(encryptedPassword);

            if (decryptedPassword != null && decryptedPassword.equals(password)) {
                isValid = true;
            }
        }
        cursor.close();
        return isValid;
    }
}