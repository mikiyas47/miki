package com.example.simpleexm;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ExamResultActivity extends AppCompatActivity {

    private TextView resultText;
    private Button backButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exam_result);

        resultText = findViewById(R.id.resultText);
        backButton = findViewById(R.id.backButton);


        // Get the score and total from the Intent
        int score = getIntent().getIntExtra("SCORE", 0);  // Default value is 0 if not found
        int total = getIntent().getIntExtra("TOTAL", 0);  // Default value is 0 if not found

        // Display the score and total
        resultText.setText("Your Score: " + score + "/" + total);

        // Set the OnClickListener for the backButton
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go back to the main activity or previous activity
                Intent intent = new Intent(ExamResultActivity.this, MainActivity.class);  // Example: go back to MainActivity
                startActivity(intent);
                finish();  // Close the current activity
            }
        });
    }
}
