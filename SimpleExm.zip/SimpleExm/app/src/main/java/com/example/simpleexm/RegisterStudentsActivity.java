package com.example.simpleexm;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterStudentsActivity extends AppCompatActivity {

    private EditText studentNameInput;
    private EditText studentPasswordInput;
    private Button registerButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_students);

        studentNameInput = findViewById(R.id.studentNameInput);
        studentPasswordInput = findViewById(R.id.studentPasswordInput);
        registerButton = findViewById(R.id.registerButton);
        dbHelper = new DatabaseHelper(this);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String studentName = studentNameInput.getText().toString().trim();
                String studentPassword = studentPasswordInput.getText().toString().trim();

                if (studentName.isEmpty() || studentPassword.isEmpty()) {
                    Toast.makeText(RegisterStudentsActivity.this, "Please enter both name and password", Toast.LENGTH_SHORT).show();
                } else {
                    String encryptedPassword = EncryptionUtil.encrypt(studentPassword);
                    boolean isInserted = dbHelper.insertStudent(studentName, encryptedPassword);
                    if (isInserted) {
                        Toast.makeText(RegisterStudentsActivity.this, "Student Registered Successfully", Toast.LENGTH_SHORT).show();
                        studentNameInput.setText("");
                        studentPasswordInput.setText("");
                    } else {
                        Toast.makeText(RegisterStudentsActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
